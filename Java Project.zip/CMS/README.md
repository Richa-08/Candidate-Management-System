# CMS

CMS is candidate management system that is built on java
Performs CRUD operations for registered candidates and their marks.
